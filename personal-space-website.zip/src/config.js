// Personalize this file. Keep secrets (OAuth client secrets / bot tokens) out of frontend code.
export const config = {
  displayName: "yourname",
  handle: "@yourhandle",
  tagline: "somewhere between the stars and my own thoughts.",
  location: "Ho Chi Minh City, Viet Nam",
  avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=320&h=320&fit=crop&crop=faces",
  coverUrl: "https://images.unsplash.com/photo-1519681393784-d120267933ba?w=1800&q=85",
  discordUserId: "905025054599962635",
  // Optional: Discord server ID with Server Widget enabled in Server Settings > Widget.
  discordServerId: "",
  // Optional links. Replace these with your own URLs.
  socials: [
    { label: "Instagram", value: "@yourinstagram", href: "https://instagram.com/" },
    { label: "GitHub", value: "yourgithub", href: "https://github.com/" },
    { label: "Discord", value: "Add me", href: "https://discord.com/users/905025054599962635" }
  ],
  // Optional direct audio file URL (mp3/ogg). Browser autoplay is intentionally disabled.
  musicUrl: "",
  musicTitle: "your song",
  musicArtist: "your artist"
};