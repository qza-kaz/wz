import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Activity, ArrowUpRight, AudioLines, Check, Circle, Copy, Disc3,
  Gamepad2, Github, Headphones, Instagram, Link2, MapPin, MessageCircle,
  Music2, Pause, Play, Radio, ShieldAlert, Sparkles, Volume2, VolumeX
} from "lucide-react";
import { config } from "./config";
import { useLanyard } from "./useLanyard";

const statusMap = {
  online: { label: "online", color: "#5de0a0" },
  idle: { label: "idle", color: "#f5c451" },
  dnd: { label: "do not disturb", color: "#f16b76" },
  offline: { label: "offline", color: "#777783" }
};

function DiscordCard({ presence, connection }) {
  const user = presence?.discord_user;
  const status = statusMap[presence?.discord_status || "offline"];
  const activities = presence?.activities || [];
  const spotify = presence?.spotify;
  const game = activities.find(a => a.type === 0);
  const custom = activities.find(a => a.type === 4);
  const otherActivity = activities.find(a => a.type !== 0 && a.type !== 4);

  const avatar = user?.avatar
    ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.${user.avatar.startsWith("a_") ? "gif" : "png"}?size=256`
    : config.avatarUrl;

  const activityLine = spotify
    ? `Listening to ${spotify.song}`
    : game
      ? `Playing ${game.name}`
      : otherActivity
        ? `${otherActivity.name}`
        : "No activity shared right now";

  return (
    <section className="panel discord-panel">
      <div className="panel-heading">
        <div className="heading-left"><span className="icon-tile discord-mark">◉</span><div><p className="eyebrow">LIVE PRESENCE</p><h2>Discord</h2></div></div>
        <span className={`live-pill ${connection === "connected" ? "is-live" : ""}`}><span />{connection === "connected" ? "LIVE" : connection.toUpperCase()}</span>
      </div>
      <div className="discord-user">
        <div className="avatar-wrap">
          <img src={avatar} alt="Discord avatar" onError={e => { e.currentTarget.src = config.avatarUrl; }} />
          <i className="status-dot" style={{ background: status.color }} />
        </div>
        <div className="user-copy">
          <strong>{user?.global_name || user?.display_name || config.displayName}</strong>
          <span>{user?.username ? `@${user.username}` : config.handle}</span>
          <small><i style={{ background: status.color }} />{status.label}</small>
        </div>
        <a className="icon-button" href={`https://discord.com/users/${config.discordUserId}`} target="_blank" rel="noreferrer" aria-label="Open Discord profile"><ArrowUpRight size={17}/></a>
      </div>
      {custom?.state && <div className="custom-status"><span>{custom.emoji?.name || "✦"}</span>{custom.state}</div>}
      <div className="activity-box">
        <div className="activity-icon">{spotify ? <Music2/> : game ? <Gamepad2/> : <Activity/>}</div>
        <div className="activity-copy"><span className="eyebrow">CURRENT ACTIVITY</span><strong>{activityLine}</strong><small>{spotify ? spotify.artist : game?.details || otherActivity?.state || "Waiting for shared activity"}</small></div>
        {spotify?.album_art_url && <img className="album-thumb" src={spotify.album_art_url} alt="Spotify album cover"/>}
      </div>
      {spotify && <div className="spotify-progress"><div><span>{spotify.song}</span><span>{spotify.artist}</span></div><div className="progress-track"><span style={{ width: `${Math.min(100, (spotify.timestamps?.start && spotify.timestamps?.end ? ((Date.now() - spotify.timestamps.start) / (spotify.timestamps.end - spotify.timestamps.start)) * 100 : 0))}%` }}/></div></div>}
      <div className="discord-foot"><span><Radio size={13}/> Presence via Lanyard</span><span>{presence?.active_on_discord_mobile ? "Mobile" : presence?.active_on_discord_desktop ? "Desktop" : " "}</span></div>
      {!presence && <p className="hint">Discord presence will appear once your account is available through Lanyard. See setup notes below.</p>}
    </section>
  );
}

function App() {
  const { data, connection } = useLanyard(config.discordUserId);
  const [copied, setCopied] = useState(false);
  const [now] = useState(() => new Date());
  const time = useMemo(() => now.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" }), [now]);

  const copyId = async () => {
    try {
      await navigator.clipboard.writeText(config.discordUserId);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {}
  };

  return (
    <main className="site-shell">
      <div className="cover" style={{ backgroundImage: `linear-gradient(180deg, rgba(8,8,12,.16), #09090d 100%), url(${config.coverUrl})` }}/>
      <div className="grain"/>
      <header className="topbar"><a className="wordmark" href="#"><span className="wordmark-dot"/>{config.displayName}<span className="wordmark-suffix">.space</span></a><div className="topbar-right"><span className="local-time"><Circle size={7} fill="currentColor"/> {time} GMT+7</span><span className="topbar-line"/><span className="topbar-label">PERSONAL WEBSITE</span></div></header>

      <div className="content">
        <section className="hero">
          <div className="hero-avatar"><img src={config.avatarUrl} alt="Profile avatar"/><span className="avatar-spark"><Sparkles size={13}/></span></div>
          <p className="eyebrow hero-kicker">A LITTLE CORNER OF THE INTERNET</p>
          <h1>{config.displayName}<span className="title-period">.</span></h1>
          <p className="handle">{config.handle}</p>
          <p className="tagline">“{config.tagline}”</p>
          <div className="location"><MapPin size={13}/>{config.location}</div>
          <div className="social-row">
            {config.socials.map((item, i) => <a key={item.label} href={item.href} target="_blank" rel="noreferrer" className="social-link"><span>{item.label}</span><ArrowUpRight size={13}/></a>)}
          </div>
        </section>

        <div className="dashboard">
          <DiscordCard presence={data} connection={connection}/>
        </div>

        <section className="quote-panel">
          <span className="quote-mark">“</span>
          <p>In every lifetime, my heart would still choose you.</p>
          <span className="quote-credit">— A THOUGHT LEFT HERE</span>
        </section>

        <footer className="footer">
          <div><span className="footer-dot"/> MADE WITH INTENTION <span className="footer-divider">/</span> © {new Date().getFullYear()} {config.displayName}</div>
          <button onClick={copyId} className="copy-id">{copied ? <Check size={13}/> : <Copy size={13}/>} {copied ? "COPIED" : "COPY DISCORD ID"}</button>
        </footer>
      </div>
    </main>
  );
}

export default App;